from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from openai_routes import router as openai_router # Corrected import
import os

app = FastAPI()

origins = [
    "http://localhost:3000",
    "localhost:3000"
]

# Configure middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

# Include the openai_router, not just "router"
app.include_router(openai_router)  # Corrected usage

@app.get("/api/chat", tags=["root"])
async def api_chat():
    return {"message": "Hello World"}
